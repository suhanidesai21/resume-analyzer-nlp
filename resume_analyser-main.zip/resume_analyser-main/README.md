# Python Resume ATS Analyzer

A beginner-friendly, pure Python Resume Analyzer that uses NLP (Natural Language Processing) to match a resume with a job description.

## Project Structure
This app uses exactly 5 Python files to keep things easy to understand for beginners:
1. `config_skills.py` - Contains the database of skills we look for.
2. `pdf_reader.py` - Reads and extracts text from your PDF files.
3. `skill_extractor.py` - The NLP engine. It uses `spaCy` to parse your resume and extract skills.
4. `analyzer.py` - Compares resume skills and JD skills, calculates score, and generates feedback.
5. `main.py` - The main entry point to run the command-line application!

## Setup

1. Open your terminal to this directory.
2. Install the necessary requirements:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the app:
   ```bash
   python main.py
   ```

*(Note: On the first run, the app will automatically download a language model `en_core_web_sm` required for NLP!)*

Enjoy making your resume ATS-friendly!
