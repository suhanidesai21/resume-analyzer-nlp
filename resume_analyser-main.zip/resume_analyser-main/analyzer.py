def calculate_ats_score(resume_skills, jd_skills):
    """
    Calculates a basic ATS score based on how many job description skills 
    are present in the resume.
    """
    if not jd_skills:
        return 0
        
    # Find overlapping skills
    matched_skills = set(resume_skills).intersection(set(jd_skills))
    
    # Example formula: (matched / required) * 100
    score = (len(matched_skills) / len(jd_skills)) * 100
    return round(score, 2)

def get_gap_analysis(resume_skills, jd_skills):
    """
    Finds which required skills are missing from the resume.
    """
    missing_skills = set(jd_skills) - set(resume_skills)
    return list(missing_skills)

def generate_suggestions(ats_score, missing_skills):
    """
    Provides automated suggestions to improve the resume based on the score and gaps.
    """
    suggestions = []
    
    # Score-based feedback
    if ats_score < 50:
        suggestions.append("Your resume needs significant improvement to pass ATS systems.")
    elif ats_score < 80:
        suggestions.append("Good start, but you can tailor your resume more to the job description.")
    else:
        suggestions.append("Excellent! Your resume matches the job description very well.")
        
    # Missing skills feedback
    if missing_skills:
        suggestions.append(f"Consider adding these missing skills if you have them: {', '.join(missing_skills)}")
        
    # General beginner tips
    suggestions.append("Make sure to use exact keywords from the job description.")
    suggestions.append("Keep your resume formatting simple. Avoid complex tables and images.")
    
    return suggestions
