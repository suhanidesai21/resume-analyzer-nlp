import spacy
from config_skills import ALL_SKILLS
import os

# Try to load the NLP model. If it's not installed, we download it.
# This makes it very beginner-friendly and automatic!
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    print("First-time setup: Downloading the NLP language model...")
    from spacy.cli import download
    download("en_core_web_sm")
    nlp = spacy.load("en_core_web_sm")

def extract_skills(text):
    """
    Uses NLP to extract skills from text by matching with our skills database.
    """
    # 1. Convert text to lowercase for easier matching
    text = text.lower()
    
    # 2. Process text with spaCy NLP 
    # This tokenizes the text and analyzes its structure
    doc = nlp(text)
    
    found_skills = set()
    
    # 3. Check for single-word skills (like "python" or "java")
    for token in doc:
        if token.text in ALL_SKILLS:
            found_skills.add(token.text)
            
    # 4. Check for multi-word skills (like "machine learning")
    # We look at noun chunks (phrases) extracted by our NLP model
    for chunk in doc.noun_chunks:
        chunk_text = chunk.text.strip().replace('\n', ' ')
        if chunk_text in ALL_SKILLS:
            found_skills.add(chunk_text)
            
    # 5. Simple fallback: check if multi-word skills exist in the text anyway
    for skill in ALL_SKILLS:
        if " " in skill and skill in text:
            found_skills.add(skill)
            
    return list(found_skills)
