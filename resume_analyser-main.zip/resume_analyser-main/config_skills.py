# A simple database of skills categorized
# A beginner would use a list like this rather than a complex database

TECH_SKILLS = [
    "python", "java", "c++", "c", "javascript", "react", "node.js",
    "html", "css", "sql", "nosql", "mongodb", "aws", "docker", "kubernetes",
    "git", "machine learning", "nlp", "artificial intelligence", "pandas",
    "numpy", "scikit-learn", "django", "flask", "fastapi", "linux", "agile",
    "devops", "cloud computing", "deep learning", "nlp", "computer vision",
    "rest api", "graphql", "tailwind"
]

SOFT_SKILLS = [
    "communication", "leadership", "teamwork", "problem solving",
    "critical thinking", "time management", "adaptability",
    "project management", "creativity"
]

# Combine them into one set so it's easier to search
ALL_SKILLS = set(TECH_SKILLS + SOFT_SKILLS)
