import PyPDF2

def extract_text_from_pdf(file_obj):
    """
    Reads a PDF file and extracts text from all pages.
    """
    text = ""
    try:
        # Support string paths (for local files)
        if isinstance(file_obj, str):
            with open(file_obj, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                for page in reader.pages:
                    text += page.extract_text() + " "
        # Support Streamlit UploadedFile objects
        else:
            reader = PyPDF2.PdfReader(file_obj)
            for page in reader.pages:
                text += page.extract_text() + " "
    except Exception as e:
        print(f"Error reading PDF: {e}")
    return text

def read_text_file(file_obj):
    """
    Reads a plain text file.
    """
    text = ""
    try:
        if isinstance(file_obj, str):
            with open(file_obj, 'r', encoding='utf-8') as file:
                text = file.read()
        else:
            text = file_obj.getvalue().decode("utf-8")
    except Exception as e:
        print(f"Error reading text file: {e}")
    return text
