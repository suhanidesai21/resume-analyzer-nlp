import streamlit as st
from pdf_reader import extract_text_from_pdf, read_text_file
from skill_extractor import extract_skills
from analyzer import calculate_ats_score, get_gap_analysis, generate_suggestions

# Set page aesthetic settings
st.set_page_config(page_title="Resume ATS Analyzer", page_icon="📄", layout="wide")

st.title("🚀 AI Resume ATS Analyzer")
st.markdown("A pure Python web app that checks how well your resume matches a job description using NLP.")

def get_file_text(uploaded_file):
    """Helper method to handle Streamlit uploaded files"""
    if uploaded_file.name.endswith('.pdf'):
        return extract_text_from_pdf(uploaded_file)
    elif uploaded_file.name.endswith('.txt'):
        return read_text_file(uploaded_file)
    return ""

# Create two columns for the layout
col1, col2 = st.columns(2)

with col1:
    st.subheader("1. Upload Resume")
    # Streamlit automatically gives us a modern drag-and-drop file uploader
    resume_file = st.file_uploader("Upload your resume (PDF or TXT)", type=['pdf', 'txt'], key="resume")
    
with col2:
    st.subheader("2. Job Description")
    jd_input_method = st.radio("Choose Input Method:", ["Paste Text", "Upload File"], horizontal=True)
    
    jd_text = ""
    if jd_input_method == "Upload File":
        jd_file = st.file_uploader("Upload Job Description (PDF or TXT)", type=['pdf', 'txt'], key="jd")
        if jd_file:
            jd_text = get_file_text(jd_file)
    else:
        # A nice text area for manual pasting
        jd_text = st.text_area("Paste Job Description here:", height=200)

# Big call-to-action button
if st.button("Analyze Resume", type="primary", use_container_width=True):
    if not resume_file:
        st.error("Please upload your resume to begin.")
    elif not jd_text:
        st.error("Please provide a job description for comparison.")
    else:
        # Show a loading spinner while NLP is running
        with st.spinner("Analyzing your resume using spaCy NLP..."):
            resume_text = get_file_text(resume_file)
            
            # Extract skills using NLP
            resume_skills = extract_skills(resume_text)
            jd_skills = extract_skills(jd_text)
            
            # Analyze using our logic file
            score = calculate_ats_score(resume_skills, jd_skills)
            missing = get_gap_analysis(resume_skills, jd_skills)
            suggestions = generate_suggestions(score, missing)
            
            st.divider()
            st.header("📊 Analysis Results")
            
            # Use Streamlit metrics to show a huge score card!
            st.metric(label="ATS Match Score", value=f"{score}%")
            if score < 50:
                st.error("Low Match - Needs significant tailoring to pass ATS.")
            elif score < 80:
                st.warning("Moderate Match - Good start, but could use more precise keywords.")
            else:
                st.success("High Match - Well tailored and ready to apply!")
                
            # Layout the Skills neatly
            col_a, col_b = st.columns(2)
            with col_a:
                st.subheader("Your Extracted Skills")
                if resume_skills:
                    for s in resume_skills:
                        st.markdown(f"- 🟢 {s.title()}")
                else:
                    st.write("None found")
                
            with col_b:
                st.subheader("Missing Required Skills")
                if missing:
                    for m in missing:
                        st.markdown(f"- 🔴 **{m.title()}**")
                else:
                    st.success("Awesome! You have all the required skills from the JD!")
                    
            # Present Suggestions gracefully
            st.subheader("💡 Suggestions for Improvement")
            for i, suggestion in enumerate(suggestions, 1):
                st.info(f"**Tip {i}**: {suggestion}")
